import React from "react";
import { useNavigate } from "react-router-dom";

const TeacherDashboard = () => {
  const navigate = useNavigate();
  return (
    <div className="container mt-5">
      <h2>Teacher Dashboard</h2>
      <div className="list-group">
        <button className="list-group-item list-group-item-action">Upload Quiz</button>
        <button className="list-group-item list-group-item-action">Check Student Results</button>
        <button className="list-group-item list-group-item-action">Check Assignments</button>
        <button className="list-group-item list-group-item-action">Reply to Doubts</button>
        <button className="list-group-item list-group-item-action">Give Feedback</button>
        <button className="list-group-item list-group-item-action">Upload Notes</button>
      </div>
    </div>
  );
};

export default TeacherDashboard;
