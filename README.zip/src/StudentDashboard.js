
import React from "react";
import { useNavigate } from "react-router-dom";

const StudentDashboard = () => {
  const navigate = useNavigate();
  return (
    <div className="container mt-5">
      <h2>Student Dashboard</h2>
      <div className="list-group">
        <button className="list-group-item list-group-item-action">Take Quiz</button>
        <button className="list-group-item list-group-item-action">View Quiz Results</button>
        <button className="list-group-item list-group-item-action">Submit Assignment</button>
        <button className="list-group-item list-group-item-action">View Progress</button>
        <button className="list-group-item list-group-item-action">Ask Doubt</button>
        <button className="list-group-item list-group-item-action">Give Feedback</button>
      </div>
    </div>
  );
};

export default StudentDashboard;

